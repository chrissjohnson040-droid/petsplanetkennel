UPLOAD TO GITHUB PAGES OR NETLIFY

1. Keep all files together.
2. Add puppy photos if desired.
3. Upload the folder contents to GitHub Pages or Netlify.
4. Contact:
Phone/WhatsApp: 0782091684
Email: petsplanetkennel@gmail.com
